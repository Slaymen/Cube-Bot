//waste basket = %F0%9F%97%91
//1 = 1%E2%83%A3
//2 = 2%E2%83%A3
//3 = 3%E2%83%A3
//4 = 4%E2%83%A3
//5 = 5%E2%83%A3
//6 = 6%E2%83%A3
//7 = 7%E2%83%A3
//8 = 8%E2%83%A3
//9 = 9%E2%83%A3
//Question Mark = %E2%9D%93
//arrow pointing left = %E2%AC%85
//arrow pointing right = %E2%9E%A1
//empty 1 = Empty1:361992629778382848
//empty 2 = Empty2:361992765044817960
//empty 3 = Empty3:361992789833023489

// console.log(data.info.username); //USERNAME
// console.log(data.info.platform); //PLATFORM
// console.log(data.info.url); //WEBSITE URL

// //ACCOUNT INFO
// console.log("Account ID: " + data.info.accountId);
// console.log("Account Username: " + data.info.username);
// console.log("Account Platform: " + data.info.platform);
// console.log("Tracker Url Link: " + data.info.url);
//
// //TOTAL STATS
// console.log(data.lifetimeStats[0].stat + ": " + data.lifetimeStats[0].value);
// console.log(data.lifetimeStats[1].stat + ": " + data.lifetimeStats[1].value);
// console.log(data.lifetimeStats[2].stat + ": " + data.lifetimeStats[2].value);
// console.log(data.lifetimeStats[3].stat + ": " + data.lifetimeStats[3].value);
// console.log(data.lifetimeStats[4].stat + ": " + data.lifetimeStats[4].value);
// console.log(data.lifetimeStats[5].stat + ": " + data.lifetimeStats[5].value);
// console.log(data.lifetimeStats[6].stat + ": " + data.lifetimeStats[6].value);
// console.log(data.lifetimeStats[7].stat + ": " + data.lifetimeStats[7].value);
// console.log(data.lifetimeStats[10].stat + ": " + data.lifetimeStats[10].value);
//
// //SOLO STATS
// console.log(data.group.solo[0].stat + ": " + data.group.solo[0].value); //wins
// console.log(data.group.solo[1].stat + ": " + data.group.solo[1].value); // top3
// console.log(data.group.solo[2].stat + ": " + data.group.solo[2].value); //top5
// console.log(data.group.solo[3].stat + ": " + data.group.solo[3].value); //top6
// console.log(data.group.solo[4].stat + ": " + data.group.solo[4].value); //top10
// console.log(data.group.solo[5].stat + ": " + data.group.solo[5].value); //top12
// console.log(data.group.solo[6].stat + ": " + data.group.solo[6].value); //top25
// console.log(data.group.solo[7].stat + ": " + data.group.solo[7].value); //matches
// console.log(data.group.solo[8].stat + ": " + data.group.solo[8].value); //kills
// console.log(data.group.solo[9].stat + ": " + data.group.solo[9].value); //time played
// console.log(data.group.solo[10].stat + ": " + data.group.solo[10].value); //kills per min
// console.log(data.group.solo[11].stat + ": " + data.group.solo[11].value); //kills per match
//
// //DUO STATS
// console.log(data.group.duo[0].stat + ": " + data.group.duo[0].value); //wins
// console.log(data.group.duo[1].stat + ": " + data.group.duo[1].value); //top3
// console.log(data.group.duo[2].stat + ": " + data.group.duo[2].value); //top5
// console.log(data.group.duo[3].stat + ": " + data.group.duo[3].value); //top6
// console.log(data.group.duo[4].stat + ": " + data.group.duo[4].value); //top10
// console.log(data.group.duo[5].stat + ": " + data.group.duo[5].value); //top12
// console.log(data.group.duo[6].stat + ": " + data.group.duo[6].value); //top25
// console.log(data.group.duo[7].stat + ": " + data.group.duo[7].value); //KD
// console.log(data.group.duo[8].stat + ": " + data.group.duo[8].value); //win%
// console.log(data.group.duo[9].stat + ": " + data.group.duo[9].value); //matches
// console.log(data.group.duo[10].stat + ": " + data.group.duo[10].value); //kills
// console.log(data.group.duo[11].stat + ": " + data.group.duo[11].value); //time played
// console.log(data.group.duo[12].stat + ": " + data.group.duo[12].value); //kills per min
// console.log(data.group.duo[13].stat + ": " + data.group.duo[13].value); //kills per match


// "\n" +
// "--------------SOLO-----------------\n" +
// data.group.solo[0].stat + ": " + data.group.solo[0].value + "\n" +
// data.group.solo[1].stat + ": " + data.group.solo[1].value + "\n" +
// data.group.solo[2].stat + ": " + data.group.solo[2].value + "\n" +
// data.group.solo[3].stat + ": " + data.group.solo[3].value + "\n" +
// data.group.solo[4].stat + ": " + data.group.solo[4].value + "\n" +
// data.group.solo[5].stat + ": " + data.group.solo[5].value + "\n" +
// data.group.solo[6].stat + ": " + data.group.solo[6].value + "\n" +
// data.group.solo[7].stat + ": " + data.group.solo[7].value + "\n" +
// data.group.solo[8].stat + ": " + data.group.solo[8].value + "\n" +
// data.group.solo[9].stat + ": " + data.group.solo[9].value + "\n" +
// data.group.solo[10].stat + ": " + data.group.solo[10].value + "\n" +
// data.group.solo[11].stat + ": " + data.group.solo[11].value + "\n" +
// "\n" +
// "--------------DUO-----------------\n" +
// data.group.duo[0].stat + ": " + data.group.duo[0].value + "\n" +
// data.group.duo[1].stat + ": " + data.group.duo[1].value + "\n" +
// data.group.duo[2].stat + ": " + data.group.duo[2].value + "\n" +
// data.group.duo[3].stat + ": " + data.group.duo[3].value + "\n" +
// data.group.duo[4].stat + ": " + data.group.duo[4].value + "\n" +
// data.group.duo[5].stat + ": " + data.group.duo[5].value + "\n" +
// data.group.duo[6].stat + ": " + data.group.duo[6].value + "\n" +
// data.group.duo[7].stat + ": " + data.group.duo[7].value + "\n" +
// data.group.duo[8].stat + ": " + data.group.duo[8].value + "\n" +
// data.group.duo[9].stat + ": " + data.group.duo[9].value + "\n" +
// data.group.duo[10].stat + ": " + data.group.duo[10].value + "\n" +
// data.group.duo[11].stat + ": " + data.group.duo[11].value + "\n" +
// data.group.duo[12].stat + ": " + data.group.duo[12].value + "\n" +
// data.group.duo[13].stat + ": " + data.group.duo[13].value, true)

//"ID: " + data.info.accountId + "\n" +

// console.log("GAMES: " + GAMES);
// console.log("ROUNDS PLAYED: " + RP);
// console.log("ROUNDS WON: " + RW);
// console.log("WINS " + WINS);
//console.log("TIME PLAYED: " + TP);

// console.log("KD: " + KD);
// console.log("WIN%: " + WIN);
// console.log("MVPS: " + MVP);
// console.log("SCORE: " + SCORE);
// console.log("KILLS: " + KILLS);
// console.log("DEATHS: " + DEATHS);
// console.log("BOMB SET: " + BS);
// console.log("HEADSHOTS: " + HS);
// console.log("BOMB DEFUSE: " + BD);
// console.log("MONEY EARNED: " + MONEY);
// console.log("HOSTAGE RESCUED: " + HR);
